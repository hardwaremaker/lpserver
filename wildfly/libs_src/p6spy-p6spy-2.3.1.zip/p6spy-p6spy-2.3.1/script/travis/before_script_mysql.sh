#!/bin/bash -e
# MySQL

mysql -e 'create database p6spy;'

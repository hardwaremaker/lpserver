# Frequently Asked Questions

* Can I use log4j?

    Yes. See the Log File Format documentation for more information.


* Can I use regular expressions to determine what is logged?

    Yes. See the Common Property File Settings documentation and refer to the stringmatcher section.


* Once the application is running, can I change the properties and enable the system to use the new properties?

    Yes. See the Common Property File Settings documentation and refer to the reloadproperties section.


* Can I use multiple database drivers?

    Yes. See the Common Property File Settings documentation for more information. Refer specifically to sections regarding realdriver2 and realdriver3.

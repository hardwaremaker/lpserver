
ant install - installs the DeploymentService
ant clean   - uninstalls the DeploymentService 

For more info, see:
http://www.jboss.org/wiki/Wiki.jsp?page=DeploymentService